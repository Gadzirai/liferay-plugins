package routines;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashStore {

    /**
     * setValue(String key, String value)
     * 
     * getValue(String key)
     * 
     * {Category} User Defined
     * 
     * 
     */
	
	static Map<String ,String> myStore = new ConcurrentHashMap<String, String>();
	
    public static void setValue(String key, String value){

    	//System.out.println("<<<Stored Key >>>" + key + "<<<Store value>>>" + value);    	
    	myStore.put(key, value);
    }
    
    public static String getValue(String key){
    	//System.out.println("<<<My Key >>>" + key + "<<<String>>>");
    	if(myStore.containsKey(key))
    		return new String(myStore.get(key));
    	return null;
    }
    
    public static void removeKey(String key){
    	myStore.remove(key);
    }
    
    public static String showValues(){
    	return myStore.values().iterator().next();
    }
    
    public static Collection<String> getAllValues(){
    	
    	return myStore.size()>0 ? myStore.values() : Collections.emptyList();
    }
    
    /*
     * We need to get the full store iterate through it and delete the keys as responses are getting sent out
     */
    public static Map<String, String> getStore(){
    	return myStore.size()>0 ? myStore : new ConcurrentHashMap<String ,String>();
    }
}
