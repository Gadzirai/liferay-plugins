package routines;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

import routines.system.Document;

/*
 * Authored by Gadzirai Moyo
 * Purpose to Determine the Type of activity of the transaction based on the provided input
 */
public class CustomMapping {

	/**
	 * CustomMapping: not return value, only print "hello" + message.
	 * 
	 * 
	 * {talendTypes} String
	 * 
	 * {Category} User Defined
	 */

	/*
	 * Financials Trancode
	 */
	private enum TranCodeValue {
		SOPY, AOPY, SBPY, CBPY, ABPY, SAPY, HAPY, CAPY, AAPY, STRN, CTRN, ATRN, COPY, PTAX, ABCE, SBCE, ABIL, SBIL, DBIL, ATPY, STPY
	}
	
	private enum NonFinTranCodeValue {
		LGIN, SALT, AMOB, SMOB, DEML, VMOB, ATXT, STXT, CTXT, SKBA, AKBA, VPRF, VKBA, OPEN, ATDP, STDP, RTDP, SSPR, RPCE, CPWD, SPWD, AEML, VEML, SEML
	}

	/*
	 * Activities From the
	 * tns:WestpacServiceRequest/RequestData/ActivityContext/
	 * Activity/Payment/PaymentType
	 */
	private enum PaymentType {
		ONETIMEPAY, BILLPAY, AP, TRANSFER, BILLORONETIMEPAY, TAX
	}

	/*
	 * Activities From the
	 * tns:WestpacServiceRequest/RequestData/ActivityContext/ActivityType
	 * 
	 * For NOTAPPLICABLE need to strip out all the white space as it's coming in as NOT APPLICABLE 
	 */
	private enum ActivityType {
		SETUP, DELETE, SUSPEND, AMEND, EXEMPT, CANCEL, DEREGISTER, NOTAPPLICABLE, REINVEST, RESET
	}

	private enum SourceApplication {
		CEE, SBCE, SSPR, 
	}
	
	private enum Tiers {
		TierOne, TierTwo, NoAuthRequired, CannotComplete
	}
	
	private enum BooleanType {
		TRUE, FALSE
	}
	
	private enum AlertVariables {
    	AlertType, OldEmail, NewEmail, OldText, NewText, OldMisc, NewMisc, LOGIN, PAYMENT, PASSWORD, BILLER        	

	}
	private final static String TRIMALL = "\\s";
	
	private final static String JOIN = "pokemon"; 
	
	private final static String DATEFORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";
	
	private final static String AUTHTYPE =  "/WestpacServiceRequest/RequestData/ActivityContext/riskEngineResult/AuthType";
	
	private final static String SECURITYALERTDETAILS = "/WestpacServiceRequest/RequestData/ActivityContext/Activity/SecurityAlert/AlertDetails";
	
	private final static String CHANGEPASSWORD = "/WestpacServiceRequest/RequestData/ActivityContext/Activity/ChangePassword";
	/*
	 * Event Details Info 
	 */
	
	private final static String MOBILEVIEWED = "Customer has viewed Mobile Number";
	
	private final static String KBAVIEWED = "Customer viewed KBA";
	
	private final static String KBAUPDATED = "Customer has updated KBA";
	
	private final static String PROFILEVIEWED = "Profile viewed";
	
	/*
	 * Host Decision
	 */
	public static String getHostDecision(String authTier, String sessAuthTier, String challenges, String maintAuthTier){

		System.out.println("<<<getHostDecision>>>> challenges  " + challenges);
		String value = "";
		if(isNotNullOrEmpty(maintAuthTier)){
			if(maintAuthTier.equalsIgnoreCase(Tiers.TierOne.toString())){
				value = "1";
			}else if(maintAuthTier.equalsIgnoreCase(Tiers.TierTwo.toString())){
				value = "2";
			}
		}
		if(isNotNullOrEmpty(authTier)){
			if(authTier.equalsIgnoreCase(Tiers.NoAuthRequired.toString())){
				value = "0";				
			}else if(authTier.equalsIgnoreCase(Tiers.TierOne.toString())){
				value = "1";
			}else if(authTier.equalsIgnoreCase(Tiers.TierTwo.toString())){
				value = "2";				
			}else if(authTier.equalsIgnoreCase(Tiers.CannotComplete.toString())){
				value = "3";				
			}
		}
		if(isNotNullOrEmpty(sessAuthTier)){
			if(sessAuthTier.equalsIgnoreCase(Tiers.NoAuthRequired.toString())){
				value = value + "|" + "0";
			}else if(sessAuthTier.equalsIgnoreCase(Tiers.TierOne.toString())){
				value = value + "|" + "1";				
			}else if(sessAuthTier.equalsIgnoreCase(Tiers.TierTwo.toString())){
				value = value + "|" + "2";				
			}else if(sessAuthTier.equalsIgnoreCase(Tiers.CannotComplete.toString())){
				value = value + "|" + "3";				
			}
		}
		return value + "|" + challenges.replaceAll("\\|","").replaceAll("[AD]", "");
		
	}
	
	/*
	 * Check if Non-Financials
	 */
	
	
	
	
	/*
	 * Get the RealTimeDisposition is the response from PRM
	 */
	public static String getRealTimeDisposition(Document input) {
        for (Node node : getNode(input,AUTHTYPE)) {
        	if(node.selectSingleNode("keyString").getText().equalsIgnoreCase("realTimeDisposition")){
        		return node.selectSingleNode("Challenge").getText().toString();
        	}
         }
		
		return "";
	}

	/*
	 * Get the RealTimeRuleFired is the response from PRM
	 */
	
	public static String getRealTimeRuleFired(Document input) {
        for (Node node : getNode(input,AUTHTYPE)) {
        	if(node.selectSingleNode("keyString").getText().equalsIgnoreCase("realTimeRuleFired")){
        		return node.selectSingleNode("Challenge").getText().toString();
        	}
         }
		
		return "";
	}

	public static String getChallenges(Document input){
		StringBuilder challenges = new StringBuilder("");
        for (Node node : getNode(input,AUTHTYPE)) {
        	challenges = challenges.append("|"+node.selectSingleNode("Challenge").getText());
         }
		return challenges.reverse().toString();
	}
	
   
	
	private static StringBuilder getDetails(String oldEmail, String newEmail, String oldText, String newText, String oldMisc, String newMisc){
		StringBuilder eventDetail = new StringBuilder("");
    	//oldEmail
		if(oldEmail.equalsIgnoreCase("1")){
			eventDetail = eventDetail.append("|" + "1");
		}else if(oldEmail.equalsIgnoreCase("0")){
			eventDetail = eventDetail.append("|" + "0");			
		}
		//newEmail
		if(newEmail.equalsIgnoreCase("1")){
			eventDetail = eventDetail.append("|" + "1");			
		}else if(newEmail.equalsIgnoreCase("0")){
			eventDetail = eventDetail.append("|" + "0");			
		}
		//oldText
		if(oldText.equalsIgnoreCase("1")){
			eventDetail = eventDetail.append("|" + "1");			
		}else if(oldText.equalsIgnoreCase("0")){
			eventDetail = eventDetail.append("|" + "0");			
		}
		//newText
		if(newText.equalsIgnoreCase("1")){
			eventDetail = eventDetail.append("|" + "1");			
		}else if(newText.equalsIgnoreCase("0")){
			eventDetail = eventDetail.append("|" + "0");			
		}
		//oldMisc
		if(isNotNullOrEmpty(oldMisc)){
			eventDetail = eventDetail.append("|" + oldMisc);			
		}
		//newMisc
		if(isNotNullOrEmpty(newMisc)){
			eventDetail = eventDetail.append("|" + newMisc);			
		}

		return eventDetail;
	}
	
	/*
	 * Get Security Alerts Events
	 */
	public static String getSecurityAlertDetail(Document input){
		String alertType = "";
		String oldEmail = "";
		String newEmail = "";
		String oldText = "";
		String newText = "";
		String oldMisc = "";
		String newMisc = "";
		
		StringBuilder loginEventDetail = new StringBuilder("");
		StringBuilder paymentEventDetail = new StringBuilder("");
		StringBuilder passwordEventDetail = new StringBuilder("");
		StringBuilder billerEventDetail = new StringBuilder("");
		
		
		StringBuilder eventDetail1 = new StringBuilder("");
		StringBuilder eventDetail2 = new StringBuilder("");
		
        for (Node node : getNode(input,SECURITYALERTDETAILS)) {
        	alertType = node.selectSingleNode(AlertVariables.AlertType.toString()).getText();
        	oldEmail = node.selectSingleNode(AlertVariables.OldEmail.toString()).getText();
        	newEmail = node.selectSingleNode(AlertVariables.NewEmail.toString()).getText();
        	oldText = node.selectSingleNode(AlertVariables.OldText.toString()).getText();
        	newText = node.selectSingleNode(AlertVariables.NewText.toString()).getText();
        	oldMisc = node.selectSingleNode(AlertVariables.OldMisc.toString()).getText();
        	newMisc = node.selectSingleNode(AlertVariables.NewMisc.toString()).getText();        	
       	
			if(alertType.equalsIgnoreCase(AlertVariables.LOGIN.toString())){
        		loginEventDetail = loginEventDetail.append(alertType+getDetails(oldEmail, newEmail, oldText, newText, oldMisc, newMisc));
			}
			if(alertType.equalsIgnoreCase(AlertVariables.PAYMENT.toString())){
    			paymentEventDetail = paymentEventDetail.append(alertType+getDetails(oldEmail, newEmail, oldText, newText, oldMisc, newMisc));
			}
			if(alertType.equalsIgnoreCase(AlertVariables.PASSWORD.toString())){
        		passwordEventDetail = passwordEventDetail.append(alertType+getDetails(oldEmail, newEmail, oldText, newText, oldMisc, newMisc));
			}
			if(alertType.equalsIgnoreCase(AlertVariables.BILLER.toString())){
        		billerEventDetail = billerEventDetail.append(alertType+getDetails(oldEmail, newEmail, oldText, newText, oldMisc, newMisc));
			}
         }
        
       
		eventDetail1 = loginEventDetail.append("|"+paymentEventDetail);
		eventDetail2 = passwordEventDetail.append("|"+billerEventDetail);
		
		return new StringBuilder("").append(eventDetail1+JOIN+eventDetail2).toString();
		
	}
	
	
	public static Boolean doesTagExist(Document input , String tag){
		
		Boolean exist = input.toString().contains(tag);
		
		//Boolean exist = getNode(input, expr).contains(tag);
		
		System.out.println("<<<>>>doesTagExist<<<>>> <<exist>> " + exist + " <<tag>> " + tag + " input " + input);
		
		return exist;
	}
	
	@SuppressWarnings("unchecked")
	private static List<Node> getNode(Document input, String expr){

		try {
	        SAXReader reader = new SAXReader();

	        InputStream in = new ByteArrayInputStream(input.toString().getBytes());
	         
	        org.dom4j.Document document = reader.read(in);

	        return document.selectNodes(expr);
	        
	      } catch (DocumentException e) {
	         e.printStackTrace();
	      }
		return new ArrayList<Node>();
	}
	
	

	
	/*
	 * Padding
	 */
	
	public static String padString(String input, Integer length,Character padChar, String padDir){
		if(padDir.equalsIgnoreCase("right")){
			return String.format("%1$-" + length + "s", input).replace(' ', padChar);
		}else if(padDir.equalsIgnoreCase("left")){
			return String.format("%1$" + length + "s", input).replace(' ', padChar);
		}
		return null;
	}
	
	/*
	 * Convert String to Doc
	 */
	public static Document convertStringtoDoc(String input){
		Document doc = new Document();
		try {
			doc.setDocument(DocumentHelper.parseText(input));
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return doc;
	}
	

	
	/*
	 * Calculate the time to check if we are still within response window
	 * input = corrId +"|"+ new String(input_row.messageId).trim() +"|"+  input_row.timestamp;
	 */
	public static Boolean isInResponseWindowCache(LocalDateTime currentDateTime, String cachedInput,long startWindow, long endWindow){
		//String correlationId = "";
		//String messageId = "";
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATEFORMAT);
		String timestamp = "";
		if(isNotNullOrEmpty(cachedInput)){

			ArrayList<String> inputList = mySplitter(cachedInput, ";");
			timestamp = inputList.get(2);

			
			//System.out.println("<<Cache String Time Stamp>>" + timestamp);
			LocalDateTime cachedDateTime = LocalDateTime.parse(timestamp, formatter);
			
			//System.out.println("<<Cache cachedDateTime>>" + cachedDateTime);
			
			Duration duration = Duration.between(cachedDateTime, currentDateTime);
			
			//System.out.println("<<duration>>" + duration);
			
			long lapsed = Math.abs(duration.toMillis());

			//System.out.println("<<lapsed>>" + lapsed);
			
			if(startWindow<=lapsed && lapsed<endWindow){
				return true;
			}
		}
		return false;
	}
	
	
	/*
	 * Calculate the time to check if we are still within response window
	 * input = corrId +"|"+ new String(input_row.messageId).trim() +"|"+  input_row.timestamp;
	 */
	public static Boolean isInResponseWindow(LocalDateTime currentDateTime, String timestamp,long startWindow, long endWindow){
		//String correlationId = "";
		//String messageId = "";
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATEFORMAT);
		
		System.out.println("<<Cache String Time Stamp>>" + timestamp);
		LocalDateTime cachedDateTime = LocalDateTime.parse(timestamp, formatter);
			
		System.out.println("<<Cache cachedDateTime>>" + cachedDateTime);
			
		Duration duration = Duration.between(cachedDateTime, currentDateTime);
			
		System.out.println("<<duration>>" + duration);
			
		long lapsed = Math.abs(duration.toMillis());

		System.out.println("<<lapsed>>" + lapsed);
			
		if(startWindow<=lapsed && lapsed<endWindow){
			return true;
		}
		
		return false;
	}
	
	/*
	 * Utility to Check for nulls or Empty fields
	 */
	public static String getValue(String value, String defaultValue){
		
		return isNotNullOrEmpty(value) ? value : defaultValue;
	}
	
	
    public static boolean isNotNullOrEmpty(String value) {
        return value != null && !value.trim().isEmpty();
    }
	
	/*
	 * TranCodeCategory
	 */
	
	public static String getTranCodeCategory(Boolean isPaymentTran, Boolean isIntlPaymenetTran, Boolean isTermDeposit, String paymentType){
		String tranCodeCat = "";
		if(isIntlPaymenetTran || isPaymentTran || isTermDeposit){
			if(isIntlPaymenetTran){
				tranCodeCat = "63";
			}else if(isPaymentTran){
				if(paymentType.equalsIgnoreCase(PaymentType.ONETIMEPAY.toString()) || paymentType.equalsIgnoreCase(PaymentType.BILLPAY.toString()) || paymentType.equalsIgnoreCase(PaymentType.BILLORONETIMEPAY.toString()) || paymentType.equalsIgnoreCase(PaymentType.AP.toString()) || paymentType.equalsIgnoreCase(PaymentType.TAX.toString())){
					tranCodeCat = "39";
				}else {
					tranCodeCat = "42";
				}
			}else if(isTermDeposit){
				tranCodeCat = "22";
			}else {
				tranCodeCat = "39";
			}
		}
		return tranCodeCat;
	}
	
	/*
	 *-- Response code from Third Party program
		/*"From Response Message. Populate with a number
		as follows:
		For Suceeded = S or R (approved): set to 0 
		For Suceeded = F and AuthenticationTier= 'TierOne'  (Fail KBA): set to 010
		For Suceeded = F and AuthenticationTier = 'TierTwo' (Fail OTV): set to 020
		For AuthenticationTier = 'CannotComplete'  set to 030

	 */
	public static String getRespCode(String providerResponse, String authenticationTier, String challenge){
		String respCode = "";

		if(providerResponse.equalsIgnoreCase("0")){
			if((mySplitter(challenge,"|").size() > 0) && (authenticationTier.equalsIgnoreCase(Tiers.TierTwo.toString())) && (mySplitter(challenge,"|").get(0).equalsIgnoreCase("F")) || ((mySplitter(challenge,"|").size() <= 0) && authenticationTier.equalsIgnoreCase(Tiers.TierTwo.toString()))){
				respCode = "020";
			}else if((mySplitter(challenge,"|").size() > 0) && (authenticationTier.equalsIgnoreCase(Tiers.TierOne.toString())) && (mySplitter(challenge,"|").get(0).equalsIgnoreCase("F")) || ((mySplitter(challenge,"|").size() <= 0) && authenticationTier.equalsIgnoreCase(Tiers.TierOne.toString()))){
				respCode = "010";			
			}else if(authenticationTier.equalsIgnoreCase(Tiers.CannotComplete.toString())){
				respCode = "030";			
			}else if(mySplitter(challenge,"|").size() > 0 && mySplitter(challenge,"|").get(0).equalsIgnoreCase("D")){
				respCode = "051";
			}else {
				respCode = "000";
			}
		}else {
			respCode = "99";
		}
			
		return respCode;
	}
	
	
	
	/*
	 * TranAmt1
	 */
	public static String getTranAmt1(Boolean isPaymentTran, Boolean isIntlPaymenetTran, Boolean isTermDeposit, String DomesticPymtAmt, BigDecimal InternationalPymtAmt, BigDecimal TermDepositAmt){
		String tranAmt1 =  "";
		if(isPaymentTran) {
			tranAmt1 = DomesticPymtAmt.toString().contains(".") ? DomesticPymtAmt.toString() : DomesticPymtAmt.toString()+".00";
		}else if(isIntlPaymenetTran) {
			tranAmt1 = InternationalPymtAmt.toString().contains(".") ? InternationalPymtAmt.toString() : InternationalPymtAmt.toString()+".00";
		}else if(isTermDeposit){
			tranAmt1 = TermDepositAmt.toString().contains(".") ? TermDepositAmt.toString() : TermDepositAmt.toString()+".00";
		}else {
			tranAmt1 = "0.00";
		}
		return tranAmt1;
	}
	
	/*
	 * TranCode For Non Financials
	 */
	public static String getNonFinTranCode(String paymentType, String activityType, String sourceApplication, String GuardianProfile, String challenge, Boolean isLogin, Boolean isSecurityAlert, Boolean isMobilePhone, Boolean isTextBanking, Boolean isMaintainAuthentication, Boolean isOpenAccount, Boolean isTermDeposit, Boolean isChangePassword, Boolean isCustomerContact, Boolean isBillerTran){
		String tranCode = "";
		/*
		 * Login
		 */
		
		if(isLogin){
			tranCode = NonFinTranCodeValue.LGIN.toString();
		}
		/*
		 * Security Alert
		 */
		
		if(isSecurityAlert){
			if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
				tranCode = NonFinTranCodeValue.SALT.toString();
			}
		}
		
		/*
		 * Mobile Phone
		 */
		if(isMobilePhone){
			if(activityType.equalsIgnoreCase(ActivityType.AMEND.toString())){
				tranCode = NonFinTranCodeValue.AMOB.toString();
			}else if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
				tranCode = NonFinTranCodeValue.SMOB.toString();
			}else if(activityType.equalsIgnoreCase(ActivityType.DEREGISTER.toString())){
				tranCode = NonFinTranCodeValue.DEML.toString();
			}else if(activityType.equalsIgnoreCase(ActivityType.NOTAPPLICABLE.toString())){
				tranCode = NonFinTranCodeValue.VMOB.toString();
			}
		}
		/*
		 * TextBanking
		 */
		if(isTextBanking){
			if(activityType.equalsIgnoreCase(ActivityType.AMEND.toString())){
				tranCode = NonFinTranCodeValue.ATXT.toString();
			}else if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
				tranCode = NonFinTranCodeValue.STXT.toString();
			}else if(activityType.equalsIgnoreCase(ActivityType.CANCEL.toString())){
				tranCode = NonFinTranCodeValue.CTXT.toString();
			}
		}
		/*
		 * MaintainAuthentication
		 * Special scenario for Amend Mobile / Amend Email / Amend KBA events
		 */
		if(isMaintainAuthentication){
			if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
				tranCode = NonFinTranCodeValue.SKBA.toString();
			}else if(activityType.equalsIgnoreCase(ActivityType.AMEND.toString())){
				if(isNotNullOrEmpty(GuardianProfile) &&  GuardianProfile.equalsIgnoreCase(ActivityType.AMEND.toString())){
					tranCode = NonFinTranCodeValue.AKBA.toString();					
				}else if(mySplitter(challenge, "|").size()>0){
					tranCode = NonFinTranCodeValue.VPRF.toString();					
				}else {
					tranCode = NonFinTranCodeValue.VPRF.toString();	
				}
			}else if(activityType.replaceAll(TRIMALL, "").equalsIgnoreCase(ActivityType.NOTAPPLICABLE.toString())){
				tranCode = NonFinTranCodeValue.VKBA.toString();					
			}
		}
		/*
		 * OpenAccount
		 */
		if(isOpenAccount){
			if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
				tranCode = NonFinTranCodeValue.OPEN.toString();
			}
		}
		/*
		 * TermDeposit
		 */
		if(isTermDeposit){
			if(activityType.equalsIgnoreCase(ActivityType.AMEND.toString())){
				tranCode = NonFinTranCodeValue.ATDP.toString();
			}else if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
				tranCode = NonFinTranCodeValue.STDP.toString();				
			}else if(activityType.equalsIgnoreCase(ActivityType.REINVEST.toString())){
				tranCode = NonFinTranCodeValue.RTDP.toString();				
			}
		}
		/*
		 * ChangePassword
		 */
		if(isChangePassword){
			if(!sourceApplication.isEmpty()){
				if(sourceApplication.equalsIgnoreCase(SourceApplication.SSPR.toString())){
					if(activityType.equalsIgnoreCase(ActivityType.RESET.toString())){
						tranCode = NonFinTranCodeValue.SSPR.toString();				
					}
				}else if(sourceApplication.equalsIgnoreCase(SourceApplication.CEE.toString())){
					if(activityType.equalsIgnoreCase(ActivityType.RESET.toString())){
						tranCode = NonFinTranCodeValue.RPCE.toString();				
					}
				}else {
					if(activityType.equalsIgnoreCase(ActivityType.RESET.toString())){
						tranCode = NonFinTranCodeValue.CPWD.toString();				
					}else {
						tranCode = NonFinTranCodeValue.SPWD.toString();								
					}

				}
			}
		}
		/*
		 * CustomerContact
		 */
		if(isCustomerContact){
			if(activityType.equalsIgnoreCase(ActivityType.AMEND.toString())){
				tranCode = NonFinTranCodeValue.AEML.toString();					
			}else if(activityType.replaceAll(TRIMALL, "").equalsIgnoreCase(ActivityType.NOTAPPLICABLE.toString())){
				tranCode = NonFinTranCodeValue.VEML.toString();					
			}else if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
				tranCode = NonFinTranCodeValue.SEML.toString();					
			}else {
				tranCode = "    ";
			}
		}
		
		/*
		 * Biller Transactions
		 * used both in Fin and Non-Fin
		 */
		if(isBillerTran){
			tranCode = getBiller(sourceApplication, activityType);
		}
		
		System.out.println("<<>>>>Non Fin Tran Code<<<>>> " + tranCode);
		return tranCode;
	}
	/*
	 * Non Financial Event Details
	 */
	
	/*
	 * Login
	 */
	public static String getLoginDetail(String activityType, String computerId){
		System.out.println("<<<getLoginDetail>>>" + computerId);
		String eventDetail = computerId.length()>40 ? (computerId.substring(0, 40) + JOIN + computerId.substring(40)) : computerId;
		return eventDetail;
	}
	
	/*
	 * MobilePhone
	 */
	public static String getMobilePhoneDetail(String activityType, String mobilePhoneNumber, String isNew, String isTrusted){
		System.out.println("<<<MobilePhone Detail>>> activityType " + activityType + " mobilePhoneNumber " + mobilePhoneNumber + " isNew " + isNew + " isTrusted " + isTrusted);
		String eventDetail = mobilePhoneNumber;
		if(isNotNullOrEmpty(isNew)){
			if(isNew.equalsIgnoreCase(BooleanType.TRUE.toString()) || isNew.equalsIgnoreCase("1")){
				eventDetail = eventDetail + JOIN + "1";
			}else if(isNew.equalsIgnoreCase(BooleanType.FALSE.toString()) || isNew.equalsIgnoreCase("0")){
				eventDetail = eventDetail + JOIN + "0";
			}
		}
		if(isNotNullOrEmpty(isTrusted)){
			if(isTrusted.equalsIgnoreCase(BooleanType.TRUE.toString()) || isTrusted.equalsIgnoreCase("1")){
				eventDetail = eventDetail + "|" + "1";			
			}else if(isTrusted.equalsIgnoreCase(BooleanType.FALSE.toString()) || isTrusted.equalsIgnoreCase("0")){
				eventDetail = eventDetail + "|" + "0";			
			}
		}
		if(activityType.replaceAll(TRIMALL, "").equalsIgnoreCase(ActivityType.NOTAPPLICABLE.toString())){
			eventDetail = eventDetail + MOBILEVIEWED;
		}
		return eventDetail;
	}
	
	/*
	 * TextBanking
	 */
	public static String getTextBankingDetail(String accountNumber, String mobilePhoneNumber, String isMobilePhoneNew, String isMobilePhoneTrusted){
		String eventDetail = accountNumber;
		if(!mobilePhoneNumber.isEmpty()){
			eventDetail = eventDetail + JOIN + mobilePhoneNumber;
		}
		if(isNotNullOrEmpty(isMobilePhoneNew)){
			if(isMobilePhoneNew.equalsIgnoreCase(BooleanType.TRUE.toString()) || isMobilePhoneNew.equalsIgnoreCase("1")){
				eventDetail = eventDetail + "|" + "1";
			}else if(isMobilePhoneNew.equalsIgnoreCase(BooleanType.FALSE.toString()) || isMobilePhoneNew.equalsIgnoreCase("0")){
				eventDetail = eventDetail + "|" + "0";
			}
		}
		if(isNotNullOrEmpty(isMobilePhoneTrusted)){
			if(isMobilePhoneTrusted.equalsIgnoreCase(BooleanType.TRUE.toString()) || isMobilePhoneTrusted.equalsIgnoreCase("1")){
				eventDetail = eventDetail + "|" + "1";
			}else if(isMobilePhoneTrusted.equalsIgnoreCase(BooleanType.FALSE.toString()) || isMobilePhoneTrusted.equalsIgnoreCase("0")){
				eventDetail = eventDetail + "|" + "0";
			}
		}
		return eventDetail;
	}
	/* uses the output of the trancode computation
	 * Biller
	 */
	public static String getBillerDetails(String tranCodeValue, String isTrusted, String newPayeeName, String newPayeeNickName, String newPayeeParticulars, String newPayeeCode, String newPayeeReference, String oldPayeeName, String oldPayeeNickName, String oldPayeeParticulars, String oldPayeeCode, String oldPayeeReference){
		System.out.println("<<<getBillerDetails>>> tranCodeValue " + tranCodeValue + " isTrusted " + isTrusted + " newPayeeName " + newPayeeName + " newPayeeNickName " + newPayeeNickName +  " newPayeeParticulars " + newPayeeParticulars + " newPayeeCode " + newPayeeCode + " newPayeeReference " + newPayeeReference + " oldPayeeName " + oldPayeeName + " oldPayeeNickName " + oldPayeeNickName + " oldPayeeParticulars " + oldPayeeParticulars + " oldPayeeCode " + oldPayeeCode + " oldPayeeReference " + oldPayeeReference);
		String eventDetail = "";
		newPayeeName = (isNotNullOrEmpty(newPayeeName) ? newPayeeName.trim() : "");
		newPayeeNickName = (isNotNullOrEmpty(newPayeeNickName) ? newPayeeNickName.trim() : "");
		newPayeeParticulars = (isNotNullOrEmpty(newPayeeParticulars) ? newPayeeParticulars.trim() : "");
		newPayeeCode = (isNotNullOrEmpty(newPayeeCode) ? newPayeeCode.trim() : "");
		newPayeeReference = (isNotNullOrEmpty(newPayeeReference) ? newPayeeReference.trim() : "");
		oldPayeeName = (isNotNullOrEmpty(oldPayeeName) ? oldPayeeName.trim() : "");
		oldPayeeNickName = (isNotNullOrEmpty(oldPayeeNickName) ? oldPayeeNickName.trim() : "");
		oldPayeeParticulars = (isNotNullOrEmpty(oldPayeeParticulars) ? oldPayeeParticulars.trim() : "");
		oldPayeeCode = (isNotNullOrEmpty(oldPayeeCode) ? oldPayeeCode.trim() : "");
		oldPayeeReference = (isNotNullOrEmpty(oldPayeeReference) ? oldPayeeReference.trim() : "");
		
		
		if(tranCodeValue.equalsIgnoreCase(TranCodeValue.SBIL.toString()) || tranCodeValue.equalsIgnoreCase(TranCodeValue.DBIL.toString()) || tranCodeValue.equalsIgnoreCase(TranCodeValue.SBCE.toString())){
			eventDetail = eventDetail + JOIN + newPayeeName + "|" + newPayeeNickName;
		}
		if(tranCodeValue.equalsIgnoreCase(TranCodeValue.ABIL.toString()) || tranCodeValue.equalsIgnoreCase(TranCodeValue.ABCE.toString())){
			eventDetail = eventDetail + JOIN + newPayeeName + "|" + newPayeeNickName + "|" + oldPayeeName + "|" + oldPayeeNickName + "|" + oldPayeeParticulars + "|" + oldPayeeCode + "|" + oldPayeeReference;			
		}
		String combined = newPayeeParticulars + "|" + newPayeeCode + "|" + newPayeeReference;
		
		if(isTrusted.equalsIgnoreCase(BooleanType.TRUE.toString()) || isTrusted.equalsIgnoreCase("1")){
			combined = combined + "|" + "1";
		}else if(isTrusted.equalsIgnoreCase(BooleanType.FALSE.toString()) || isTrusted.equalsIgnoreCase("0")){
			combined = combined + "|" + "0";
		}
		
		return combined + eventDetail;
	}
	/*
	 * CustomerContact
	 */
	public static String getCustomerContactDetail(String contactDetail){
		String eventDetail = contactDetail.length()>40 ? (contactDetail.substring(0, 40) + JOIN + contactDetail.substring(40)) : contactDetail;
		return eventDetail;

	}

	/*
	 * MaintainAuthentication
	 * 
	 */
	public static String getMaintainAuthenticationDetail(String authenticationTier, String guardianProfile){
		System.out.println("<<<MaintainAuthentication>>> authenticationTier " + authenticationTier + " guardianProfile " + guardianProfile);
		String eventDetail = "";
		if(isNotNullOrEmpty(guardianProfile)){
			if(guardianProfile.replaceAll(TRIMALL, "").equalsIgnoreCase(ActivityType.NOTAPPLICABLE.toString())){
				eventDetail = authenticationTier + JOIN + KBAVIEWED;
			}else if(guardianProfile.equalsIgnoreCase(ActivityType.AMEND.toString())){
				eventDetail = authenticationTier + JOIN + KBAUPDATED;
			}
		}
		else {
			eventDetail = authenticationTier + JOIN + PROFILEVIEWED;
		}
		return eventDetail;
	}
	/*
	 * OpenAccount
	 */
	public static String getOpenAccount(String accountNumber){
		System.out.println("<<<OpenAccount>>> " +accountNumber+JOIN + "|" );
		
		return accountNumber+JOIN+ "|" ;
	}
	
	
	
	public static String getEventDetails(String details, Integer pos){
		
		System.out.println("<<<<Event Details>>>> " + details + " Position " + pos + " Value ");
		if(details.length()>0 && details.contains(JOIN)){
			String[] data = details.split(JOIN);
			//System.out.println("<<<<Event Details>>>> " + details + " Position " + pos + " Value " + data[pos]);
			return data[pos];
			//return mySplitter(details, JOIN).get(pos.intValue());
		}
		return "";
	}
	
	
	/*
	 * Non Financial Event Details
	 */

	
	/*
	 * Xfowardfor
	 */
	
	public static ArrayList<String> getIP(String xfwrdFor){
		return mySplitter(xfwrdFor, ",");
	}
	
	/*
	 * mySplitter
	 */

	private static ArrayList<String> mySplitter(String input, String splitter){
		String[] inputSplit = new String[]{""};
		if(isNotNullOrEmpty(input)){
			inputSplit = input.split(splitter);
			ArrayList<String> splitRes = new ArrayList<String>(Arrays.asList(inputSplit));
			return splitRes;
		}
		return new ArrayList<String>();
	}

	
	
	
	/*
	 * TranCode For Financials
	 */
	public static String getTranCode(String paymentType, String activityType, String sourceApplication, Boolean isPaymentTran, Boolean isBillerTran, Boolean isIntlPaymenetTran) {
		String tranCode = "";
		//System.out.println("<<paymentType>>" + paymentType + "<<isPayment>>" + (paymentTran != null && paymentTran.trim().length() > 0) +  "<<isBillerTran>>" +(billerTran !=null && billerTran.trim().length() > 0) + "<<isIntlPaymenetTran>>" + (intlPaymenetTran!=null && intlPaymenetTran.trim().length()>0));
		
		/*
		 * This section for Payments Type Transactions 
		 */
		if (isPaymentTran) {
			if (paymentType.equalsIgnoreCase(PaymentType.ONETIMEPAY.toString())) {
				if (activityType.equalsIgnoreCase(ActivityType.SETUP.toString())) {
					tranCode = TranCodeValue.SOPY.toString();
				}else {
					tranCode = TranCodeValue.AOPY.toString();
				}
			}else if(paymentType.equalsIgnoreCase(PaymentType.BILLPAY.toString())){
				if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
					tranCode = TranCodeValue.SBPY.toString();
				}else if(activityType.equalsIgnoreCase(ActivityType.DELETE.toString())){
					tranCode = TranCodeValue.CBPY.toString();
				}else {
					tranCode = TranCodeValue.ABPY.toString();
				}
			}else if(paymentType.equalsIgnoreCase(PaymentType.AP.toString())){
				if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
					tranCode = TranCodeValue.SAPY.toString();					
				}else if(activityType.equalsIgnoreCase(ActivityType.SUSPEND.toString())){
					tranCode = TranCodeValue.HAPY.toString();
				}else if(activityType.equalsIgnoreCase(ActivityType.DELETE.toString())){
					tranCode = TranCodeValue.CAPY.toString();
				}else {
					tranCode = TranCodeValue.AAPY.toString();
				}
			}else if(paymentType.equalsIgnoreCase(PaymentType.TRANSFER.toString())){
				if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
					tranCode = TranCodeValue.STRN.toString();
				}else if(activityType.equalsIgnoreCase(ActivityType.DELETE.toString())){
					tranCode = TranCodeValue.CTRN.toString();
				}else if(activityType.equalsIgnoreCase(ActivityType.AMEND.toString())){
					tranCode = TranCodeValue.ATRN.toString();
				}
			}else if(paymentType.equalsIgnoreCase(PaymentType.BILLORONETIMEPAY.toString())){
				if(activityType.equalsIgnoreCase(ActivityType.CANCEL.toString())){
					tranCode = TranCodeValue.COPY.toString();					
				}
			}else if(paymentType.equalsIgnoreCase(PaymentType.TAX.toString())){
				if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
					tranCode = TranCodeValue.PTAX.toString();					
				}
			}
		}
		/*
		 * Biller Transactions
		 * used both in Fin and Non-Fin
		 */
		if(isBillerTran){
			tranCode = getBiller(sourceApplication, activityType);
		}
		/*
		 * International Payments Transactions
		 */
		if(isIntlPaymenetTran){
			if(activityType.equalsIgnoreCase(ActivityType.AMEND.toString())){
				tranCode = TranCodeValue.ATPY.toString();				
			}else if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
				tranCode = TranCodeValue.STPY.toString();				
			}
		}
		return tranCode;
	}
	
	private static String getBiller(String sourceApplication, String activityType){
		String tranCode = "";
		if(sourceApplication.equalsIgnoreCase(SourceApplication.CEE.toString())){
			if(activityType.equalsIgnoreCase(ActivityType.AMEND.toString())){
				tranCode = TranCodeValue.ABCE.toString();
			}else if(activityType.equalsIgnoreCase(ActivityType.EXEMPT.toString())){
				tranCode = TranCodeValue.SBCE.toString();					
			}
		}else {
			if(activityType.equalsIgnoreCase(ActivityType.AMEND.toString())){
				tranCode = TranCodeValue.ABIL.toString();				
			}else if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
				tranCode = TranCodeValue.SBIL.toString();					
			}else if(activityType.equalsIgnoreCase(ActivityType.DELETE.toString())){
				tranCode = TranCodeValue.DBIL.toString();					
			}else if(activityType.equalsIgnoreCase(ActivityType.EXEMPT.toString())){
				tranCode = TranCodeValue.SBCE.toString();					
			}
		}
		return tranCode;
	}
}


