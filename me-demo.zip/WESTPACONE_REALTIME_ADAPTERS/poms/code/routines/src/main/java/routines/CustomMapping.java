package routines;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

import routines.system.Document;

/*
 * Authored by Gadzirai Moyo
 * Purpose to Determine the Type of activity of the transaction based on the provided input
 */
public class CustomMapping {

	/**
	 * CustomMapping: not return value, only print "hello" + message.
	 * 
	 * 
	 * {talendTypes} String
	 * 
	 * {Category} User Defined
	 */

	/*
	 * Trancode
	 */
	private enum TranCodeValue {
		SOPY, AOPY, SBPY, CBPY, ABPY, SAPY, HAPY, CAPY, AAPY, STRN, CTRN, ATRN, COPY, PTAX, ABCE, SBCE, ABIL, SBIL, DBIL, ATPY, STPY
	}

	/*
	 * Activities From the
	 * tns:WestpacServiceRequest/RequestData/ActivityContext/
	 * Activity/Payment/PaymentType
	 */
	private enum PaymentType {
		ONETIMEPAY, BILLPAY, AP, TRANSFER, BILLORONETIMEPAY, TAX
	}

	/*
	 * Activities From the
	 * tns:WestpacServiceRequest/RequestData/ActivityContext/ActivityType
	 */
	private enum ActivityType {
		SETUP, DELETE, SUSPEND, AMEND, EXEMPT, CANCEL
	}

	private enum SourceApplication {
		CEE, SBCE
	}
	
	private enum Tiers {
		TierOne, TierTwo, NoAuthRequired, CannotComplete
	}
	
	/*
	 * Host Decision
	 */
	public static String getHostDecision(String authTier, String sessAuthTier, String challenges){
		String value = "";
		if(isNotNullOrEmpty(authTier)){
			if(authTier.equalsIgnoreCase(Tiers.NoAuthRequired.toString())){
				value = "0";				
			}else if(authTier.equalsIgnoreCase(Tiers.TierOne.toString())){
				value = "1";
			}else if(authTier.equalsIgnoreCase(Tiers.TierTwo.toString())){
				value = "2";				
			}else if(authTier.equalsIgnoreCase(Tiers.CannotComplete.toString())){
				value = "3";				
			}
		}
		if(isNotNullOrEmpty(sessAuthTier)){
			if(sessAuthTier.equalsIgnoreCase(Tiers.NoAuthRequired.toString())){
				value = value + "|" + "0";
			}else if(sessAuthTier.equalsIgnoreCase(Tiers.TierOne.toString())){
				value = value + "|" + "1";				
			}else if(sessAuthTier.equalsIgnoreCase(Tiers.TierTwo.toString())){
				value = value + "|" + "2";				
			}else if(sessAuthTier.equalsIgnoreCase(Tiers.CannotComplete.toString())){
				value = value + "|" + "3";				
			}
		}
		return value + challenges;
	}
	
	/*
	 * Check if Non-Financials
	 */
	
	
	
	
	/*
	 * Get the RealTimeDisposition is the response from PRM
	 */
	public static String getRealTimeDisposition(Document input) {
        for (Node node : getNode(input)) {
        	if(node.selectSingleNode("keyString").getText().equalsIgnoreCase("realTimeDisposition")){
        		return node.selectSingleNode("Challenge").getText().toString();
        	}
         }
		
		return "";
	}

	/*
	 * Get the RealTimeRuleFired is the response from PRM
	 */
	
	public static String getRealTimeRuleFired(Document input) {
        for (Node node : getNode(input)) {
        	if(node.selectSingleNode("keyString").getText().equalsIgnoreCase("realTimeRuleFired")){
        		return node.selectSingleNode("Challenge").getText().toString();
        	}
         }
		
		return "";
	}

	public static String evaluateXMLLoopingFields(Document input){
		StringBuffer challenges = new StringBuffer("");
        for (Node node : getNode(input)) {
        	challenges = challenges.append("|"+node.selectSingleNode("Challenge").getText());
         }
		
		return challenges.toString();
	}
	
	@SuppressWarnings("unchecked")
	private static List<Node> getNode(Document input){

		try {
	        SAXReader reader = new SAXReader();

	        InputStream in = new ByteArrayInputStream(input.toString().getBytes());
	         
	        org.dom4j.Document document = reader.read(in);

	        return document.selectNodes("/WestpacServiceRequest/RequestData/ActivityContext/riskEngineResult/AuthType" );
	        
	      } catch (DocumentException e) {
	         e.printStackTrace();
	      }
		return new ArrayList<Node>();
	}
	
	/*
	 * public static String evaluateXMLLoopingFields(Document input){
		try{
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			InputStream in = new ByteArrayInputStream(input.toString().getBytes());
			org.w3c.dom.Document doc = dBuilder.parse(in);
			System.out.println("<<<evaluateXMLLoopingFields>>>input " + input + " <<>> in " + in);
			//optional, but recommended
			//read this - http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
			doc.getDocumentElement().normalize();
			
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList nList = doc.getElementsByTagName("AuthType");
			
			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);
						
				System.out.println("\nCurrent Element :" + nNode.getNodeName());
						
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;

					System.out.println("keyString : " + eElement.getElementsByTagName("keyString").item(0).getTextContent());
					System.out.println("Challenge : " + eElement.getElementsByTagName("Challenge").item(0).getTextContent());

				}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}

		
		return null;
	}
	
	*/
	
	
	/*
	 * Xfowardfor
	 */
	
	public static ArrayList<String> getIP(String xfwrdFor){
		String[]  IPArray = new String[]{""};
		if(isNotNullOrEmpty(xfwrdFor)){

			IPArray = xfwrdFor.split(",");
			ArrayList<String> IPList = new ArrayList<String>(Arrays.asList(IPArray));
			return IPList;
		}
		return new ArrayList<String>(Arrays.asList(IPArray));
	}
	
	/*
	 * Padding
	 */
	
	public static String padString(String input, Integer length,Character padChar, String padDir){
		if(padDir.equalsIgnoreCase("right")){
			return String.format("%1$-" + length + "s", input).replace(' ', padChar);
		}else if(padDir.equalsIgnoreCase("left")){
			return String.format("%1$" + length + "s", input).replace(' ', padChar);
		}
		return null;
	}
	
	/*
	 * Convert String to Doc
	 */
	public static Document convertStringtoDoc(String input){
		Document doc = new Document();
		try {
			doc.setDocument(DocumentHelper.parseText(input));
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return doc;
	}
	

	
	/*
	 * Calculate the time to check if we are still within response window
	 * input = corrId +"|"+ new String(input_row.messageId).trim() +"|"+  input_row.timestamp;
	 */
	public static Boolean isInResponseWindowCache(LocalDateTime currentDateTime, String cachedInput,long startWindow, long endWindow){
		//String correlationId = "";
		//String messageId = "";
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
		String timestamp = "";
		if(isNotNullOrEmpty(cachedInput)){
			String[] inputArray = new String[]{""};
			
			inputArray = cachedInput.split(";");
			ArrayList<String> inputList = new ArrayList<String>(Arrays.asList(inputArray));
			//correlationId = inputList.get(0);
			//messageId = inputList.get(1);
			timestamp = inputList.get(2);

			
			//System.out.println("<<Cache String Time Stamp>>" + timestamp);
			LocalDateTime cachedDateTime = LocalDateTime.parse(timestamp, formatter);
			
			//System.out.println("<<Cache cachedDateTime>>" + cachedDateTime);
			
			Duration duration = Duration.between(cachedDateTime, currentDateTime);
			
			//System.out.println("<<duration>>" + duration);
			
			long lapsed = Math.abs(duration.toMillis());

			//System.out.println("<<lapsed>>" + lapsed);
			
			if(startWindow<=lapsed && lapsed<endWindow){
				return true;
			}
		}
		return false;
	}
	
	
	/*
	 * Calculate the time to check if we are still within response window
	 * input = corrId +"|"+ new String(input_row.messageId).trim() +"|"+  input_row.timestamp;
	 */
	public static Boolean isInResponseWindow(LocalDateTime currentDateTime, String timestamp,long startWindow, long endWindow){
		//String correlationId = "";
		//String messageId = "";
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
		
		System.out.println("<<Cache String Time Stamp>>" + timestamp);
		LocalDateTime cachedDateTime = LocalDateTime.parse(timestamp, formatter);
			
		System.out.println("<<Cache cachedDateTime>>" + cachedDateTime);
			
		Duration duration = Duration.between(cachedDateTime, currentDateTime);
			
		System.out.println("<<duration>>" + duration);
			
		long lapsed = Math.abs(duration.toMillis());

		System.out.println("<<lapsed>>" + lapsed);
			
		if(startWindow<=lapsed && lapsed<endWindow){
			return true;
		}
		
		return false;
	}
	
	/*
	 * Utility to Check for nulls or Empty fields
	 */
	public static String getValue(String value, String defaultValue){
		
		return isNotNullOrEmpty(value) ? value : defaultValue;
	}
	
	
    public static boolean isNotNullOrEmpty(String value) {
        return value != null && !value.trim().isEmpty();
    }
	
	/*
	 * TranCodeCategory
	 */
	
	public static String getTranCodeCategory(Boolean isPaymentTran, Boolean isIntlPaymenetTran, Boolean isTermDeposit, String paymentType){
		String tranCodeCat = "";
		if(isIntlPaymenetTran || isPaymentTran || isTermDeposit){
			if(isIntlPaymenetTran){
				tranCodeCat = "63";
			}else if(isPaymentTran){
				if(paymentType.equalsIgnoreCase(PaymentType.ONETIMEPAY.toString()) || paymentType.equalsIgnoreCase(PaymentType.BILLPAY.toString()) || paymentType.equalsIgnoreCase(PaymentType.BILLORONETIMEPAY.toString()) || paymentType.equalsIgnoreCase(PaymentType.AP.toString()) || paymentType.equalsIgnoreCase(PaymentType.TAX.toString())){
					tranCodeCat = "63";
				}else {
					tranCodeCat = "42";
				}
			}else if(isTermDeposit){
				tranCodeCat = "22";
			}else {
				tranCodeCat = "39";
			}
		}
		return tranCodeCat;
	}
	
	/*
	 *-- Response code from Third Party program
		/*"From Response Message. Populate with a number
		as follows:
		For Suceeded = S or R (approved): set to 0 
		For Suceeded = F and AuthenticationTier= 'TierOne'  (Fail KBA): set to 010
		For Suceeded = F and AuthenticationTier = 'TierTwo' (Fail OTV): set to 020
		For AuthenticationTier = 'CannotComplete'  set to 030

	 */
	
	public static String getRespCode(String providerResponse, String authenticationTier, String challenge){
		String respCode = "";
		
		String[] authTypes = new String[]{""};
		
		authTypes = challenge.split("|");
		
		ArrayList<String> authTypeList = new ArrayList<String>(Arrays.asList(authTypes));
		
		if(providerResponse.equalsIgnoreCase("0")){
			if((authTypeList.size() > 0) && (authenticationTier.equalsIgnoreCase(Tiers.TierTwo.toString())) && (challenge.contains("F")) || ((authTypeList.size() <= 0) && authenticationTier.equalsIgnoreCase(Tiers.TierTwo.toString()))){
				respCode = "020";
			}else if((authTypeList.size() > 0) && (authenticationTier.equalsIgnoreCase(Tiers.TierOne.toString())) && (challenge.contains("F")) || ((authTypeList.size() <= 0) && authenticationTier.equalsIgnoreCase(Tiers.TierOne.toString()))){
				respCode = "010";			
			}else if(authenticationTier.equalsIgnoreCase(Tiers.CannotComplete.toString())){
				respCode = "030";			
			}else {
				respCode = "000";
			}
		}else {
			respCode = "99";
		}
			
		return respCode;
	}

	/*
	 * TranAmt1
	 */
	public static String getTranAmt1(Boolean isPaymentTran, Boolean isIntlPaymenetTran, Boolean isTermDeposit, String DomesticPymtAmt, BigDecimal InternationalPymtAmt, BigDecimal TermDepositAmt){
		String tranAmt1 =  "";
		if(isPaymentTran) {
			tranAmt1 = DomesticPymtAmt.toString();
		}else if(isIntlPaymenetTran) {
			tranAmt1 = InternationalPymtAmt.toString();;
		}else if(isTermDeposit){
			tranAmt1 = TermDepositAmt.toString();;
		}else {
			tranAmt1 = "0.00";
		}
		return tranAmt1;
	}
	
	/*
	 * TranCode
	 */
	public static String getTranCode(String paymentType, String activityType, String sourceApplication, Boolean isPaymentTran, Boolean isBillerTran, Boolean isIntlPaymenetTran) {
		String tranCode = "";
		//System.out.println("<<paymentType>>" + paymentType + "<<isPayment>>" + (paymentTran != null && paymentTran.trim().length() > 0) +  "<<isBillerTran>>" +(billerTran !=null && billerTran.trim().length() > 0) + "<<isIntlPaymenetTran>>" + (intlPaymenetTran!=null && intlPaymenetTran.trim().length()>0));
		
		/*
		 * This section for Payments Type Transactions 
		 */
		if (isPaymentTran) {
			if (paymentType.equalsIgnoreCase(PaymentType.ONETIMEPAY.toString())) {
				if (activityType.equalsIgnoreCase(ActivityType.SETUP.toString())) {
					tranCode = TranCodeValue.SOPY.toString();
				}else {
					tranCode = TranCodeValue.AOPY.toString();
				}
			}else if(paymentType.equalsIgnoreCase(PaymentType.BILLPAY.toString())){
				if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
					tranCode = TranCodeValue.SBPY.toString();
				}else if(activityType.equalsIgnoreCase(ActivityType.DELETE.toString())){
					tranCode = TranCodeValue.CBPY.toString();
				}else {
					tranCode = TranCodeValue.ABPY.toString();
				}
			}else if(paymentType.equalsIgnoreCase(PaymentType.AP.toString())){
				if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
					tranCode = TranCodeValue.SAPY.toString();					
				}else if(activityType.equalsIgnoreCase(ActivityType.SUSPEND.toString())){
					tranCode = TranCodeValue.HAPY.toString();
				}else if(activityType.equalsIgnoreCase(ActivityType.DELETE.toString())){
					tranCode = TranCodeValue.CAPY.toString();
				}else {
					tranCode = TranCodeValue.AAPY.toString();
				}
			}else if(paymentType.equalsIgnoreCase(PaymentType.TRANSFER.toString())){
				if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
					tranCode = TranCodeValue.STRN.toString();
				}else if(activityType.equalsIgnoreCase(ActivityType.DELETE.toString())){
					tranCode = TranCodeValue.CTRN.toString();
				}else if(activityType.equalsIgnoreCase(ActivityType.AMEND.toString())){
					tranCode = TranCodeValue.ATRN.toString();
				}
			}else if(paymentType.equalsIgnoreCase(PaymentType.BILLORONETIMEPAY.toString())){
				if(activityType.equalsIgnoreCase(ActivityType.CANCEL.toString())){
					tranCode = TranCodeValue.COPY.toString();					
				}
			}else if(paymentType.equalsIgnoreCase(PaymentType.TAX.toString())){
				if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
					tranCode = TranCodeValue.PTAX.toString();					
				}
			}
			
		}
		
		/*
		 * Biller Transactions
		 */
		if(isBillerTran){
			if(sourceApplication.equalsIgnoreCase(SourceApplication.CEE.toString())){
				if(activityType.equalsIgnoreCase(ActivityType.AMEND.toString())){
					tranCode = TranCodeValue.ABCE.toString();
				}else if(activityType.equalsIgnoreCase(ActivityType.EXEMPT.toString())){
					tranCode = TranCodeValue.SBCE.toString();					
				}
			}else {
				if(activityType.equalsIgnoreCase(ActivityType.AMEND.toString())){
					tranCode = TranCodeValue.ABIL.toString();				
				}else if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
					tranCode = TranCodeValue.SBIL.toString();					
				}else if(activityType.equalsIgnoreCase(ActivityType.DELETE.toString())){
					tranCode = TranCodeValue.DBIL.toString();					
				}else if(activityType.equalsIgnoreCase(ActivityType.EXEMPT.toString())){
					tranCode = TranCodeValue.SBCE.toString();					
				}
			}
		}
		
		/*
		 * International Payments Transactions
		 */
		if(isIntlPaymenetTran){
			if(activityType.equalsIgnoreCase(ActivityType.AMEND.toString())){
				tranCode = TranCodeValue.ATPY.toString();				
			}else if(activityType.equalsIgnoreCase(ActivityType.SETUP.toString())){
				tranCode = TranCodeValue.STPY.toString();				
			}
		}
		
		return tranCode;
	}
}


